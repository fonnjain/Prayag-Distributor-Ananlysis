Prayag India — Anant Singh FY2026-27 YTD Pack
Generated: 2026-07-28T07:11:24.066Z

WHY THE FIGURES DIFFER FROM THE PREVIOUS PACK
==============================================
Four bugs were fixed between the previous pack and this one. None of
the differences are performance changes.

1. Three LEFT members excluded (Jagdev, Shiv Kumar, Ravi Upadhyay)
   Achievement rises 51.7% → 58.4% — ORGANISATIONAL, not commercial.

2. New-party order booking now included (+Rs 25.77 lakh, 11.7% of secondary)

3. Removed retailers separated from active (224 across team)
   Labelled by last active year (not "year of removal" — sheets hold no removal date).

4. Period stamping added — every document carries period covered, cutoff, generation time.

HEAD-CANON ALIASES (unrelated to Anant Singh)
=============================================
Five head merges applied on the same day:
  Sandeep Ji → Sandeep Dadheech, Rizvi Ji → Syed Aqil Rizvi,
  Bijju → Biju C.O, Lalan → Lalan Kumar, Nasir Husain → Nasir Hussain Khan.
Anant Singh was NEVER split. These do not affect this pack.

ACCEPTANCE FIGURES (team, active-10 basis)
==========================================
Order booking  : Rs 2.35 Cr (Rs 23,549,308)
Sales received : Rs 2.41 Cr
Target to date : Rs 4.03 Cr
Achievement    : 58.4%
Visits         : 4,522 (dashboard col AF)
Retailers      : 748 (dashboard col N)

Prasun Chatterjee (7 controls):
  73 retailers, 34 active | OB Rs 26,21,109 | Sale Rs 26,13,934
  395 visits / 1,704 required | Top-5 share 64.0%
  Effective retailers 9.9 | Cost ratio 5.94%

Removed retailers (reported separately):
  Ravinder Puri 64 · Prasun Chatterjee 47 · Manish Gupta 39
  Shivam Chauhan 58 · Ravi (Faridabad) 11 · Rinku 5 · others 0 · Total 224

DEPARTED MEMBERS (no forward reports generated)
================================================
Jagdev, Shiv Kumar, Ravi Upadhyay — status LEFT.
Historical business preserved in state head report.

DATA CUTOFF: 30 June 2026
