# Replit Prompt — BUILD THE SCHEMES SECTION (a nudge engine, not a report)

> **Attach `Prayag_Scheme_Master.xlsx`** with this prompt. It has three tabs — SLABS, BASKET_MAP,
> CONDITIONS — that can be wired straight in.
> Paste everything below the line.

---

# Build a SCHEMES section. This is a SELLING TOOL, not a report.

## THE MECHANIC — this is the whole idea, so get it right

A slab pays a percentage on the distributor's **ENTIRE billing for the period**, not just on the
amount above the threshold. So crossing a slab is worth far more than the top-up that gets you there.

**Example:** a distributor has billed **₹12.5 Lac** of PTMT this quarter, earning **5%** (= ₹62,500).
The next slab is ₹15 Lac at **6.5%** (= ₹97,500). Ordering **₹2.5 Lac more** earns them
**₹35,000 extra** — a **14% return on that order**.

**Most distributors don't know this. Nor do our salespeople. Nobody is doing the arithmetic.**
The app must do it, for every distributor, every basket, every day.

**Quantified from Q1 actuals: 328 distributor-basket combinations were within reach of a slab.
₹2.49 Cr of incremental sale was available for ₹19.6 L of rebate — about ₹30 L of extra
contribution at a 20% margin. In one quarter. That is what this section is worth.**

---

## ⭐ THE ROI FILTER — the single rule that makes this work

**Only surface a nudge when the top-up returns ≥ 5% to the distributor.**

`roi_to_them = they_earn / gap_to_close`

Where `they_earn = (next_threshold × next_rate) − (billed_so_far × current_rate)`

**Suppress everything below 5%.** In Q1 there were 51 combinations where a distributor would have had
to buy **₹0.4 Cr more to earn ₹0.9 L**. Pitching those wastes the salesperson's time and destroys
their credibility. **A nudge engine that cries wolf gets ignored, and then the whole feature is dead.**

Make the threshold configurable, defaulting to 5%.

---

## THE TABS

### 1. Scheme Cockpit (management)
Total live opportunity in rupees. Which schemes are running. **Days to deadline.** Scheme cost
incurred to date. Q2 clock.

### 2. ⭐ THE NUDGE LIST (salespeople) — this is the product
A ranked, filterable action list. One row per distributor × basket:

| distributor | basket | billed so far | current rate | next slab | **GAP** | **they earn** | ROI to them | days left | status |

- Rank by `they_earn` descending.
- Filter by State Head, salesperson, territory, basket, ROI.
- Exportable, so a salesperson can take it on the road.

### 3. Distributor Scorecard (for a sales visit)
**One distributor, ALL their schemes on one screen** — quarterly baskets, annual, single-bill,
product-specific. Plus their dues status. **Printable as a one-pager to hand over.**

### 4. ⭐ Bulk Order Engine (single-bill schemes)
These are **NOT cumulative** — the quantity must be on **ONE invoice**, **one Cat No**.
(Cistern 100pc = 10%, 400pc = 12%, 800pc = 14%. T-Handle Tap 120WS: 2700pc = 2% … 10080pc = 4%.
Teflon Tape: 6 cartons = 4%, 20 = 8%.)

**The pitch is ORDER CONSOLIDATION:** *"You are buying 100 cisterns anyway, spread across three
orders this month. Put them on ONE order and take 10%."* Same volume, no extra spend, instant win.

Detect this by looking at a distributor's **recent order pattern** — if their trailing 60-day volume
of a Cat No exceeds a single-bill threshold but arrived across several invoices, surface it.

### 5. Annual Tracker
Progress toward the annual slab (₹36L = 1% / ₹50L = 1.5% / ₹65L = 2% / ₹90L = 2.5%).
**Plus the anti-decline clause** (see below).

### 6. Sales Head Cockpit
Territory rollup: total opportunity in my patch, my ranked nudge list, my distributors at risk of
forfeiting, my scheme cost. **A head needs to direct effort, not read rows.**

### 7. Trip Board
The trip incentives — Goa, Thailand, Vietnam, Dubai, Mauritius, Singapore. Who is close.
*"You are ₹1.2 Lac from Vietnam."* **This has an emotional pull that a cash rebate does not. Use it.**

### 8. Scheme Master (reference)
All schemes, structured — from the attached workbook.

---

## THE PITCH — generate this sentence automatically

> *"You have billed ₹12.5 Lac of PTMT this quarter and are earning 5%. Order ₹2.5 Lac more before
> **25 September** and you cross ₹15 Lac — which pays **6.5% on the whole ₹15 Lac**, not just the
> extra. That is **₹35,000 more** for ₹2.5 Lac of buying. **A 14% return on that order.**"*

Specific. Their gain, not our target. A real deadline. The slab-pays-on-everything hook stated plainly.

---

## ⚠️ CONDITIONS THAT VOID A SCHEME — check EVERY one before pitching

Taken verbatim from the scheme documents. See the CONDITIONS tab of the attached workbook.

1. **"Material Actually dispatched will only be Considered"** → the slab base is **SALE (dispatched)**,
   from SALE SHEET 26-27 (`19LQGpkbZiecGaXdBvl48rPZT2LUz3sKekeKX5fHu7Ps`), **not order booking**.
2. **"Pending Orders shall not be considered"** → exclude the pending book.
3. **"Retail sale only. Supplies to Projects and Govt. Deptt. will not be considered"** →
   **EXCLUDE Govt / GeM / JJM / Project / Non-territory from the slab base.**
4. **"Payments of All Bills must be cleared within the due dates"** → **a distributor with overdue
   bills earns NOTHING.** Join to PARTY O/S & PAYMENT 26-27 (`1oHFpXqVDPRF3Vi3WV9MdNcxkHNjgytLPxXUQgM6o1ok`).
   **Do not pitch them — it would be a false promise.** Show **"BLOCKED — clear dues first"**, which is
   itself a powerful collection lever.
5. **"Order must be sent to the Distributor by 25th of every Month"** → **the real deadline.** Orders
   after the 25th bill in the next month. **The Q2 cut-off is 25 September, not 30 September.**
6. **"Scheme will be Allowed in the Bill itself"** → off-invoice, already inside Taxable Value.
   **Do not deduct it twice.**
7. **"Orders cannot be Mixed for Different Cat. Nos."** → single-bill schemes need **one Cat No, one
   invoice**.

---

## ⚠️ THE ANNUAL ANTI-DECLINE CLAUSE — must be a PROJECTION, never a verdict

Every annual scheme says: *"Sale during FY 2026-27 should not be Less than Last year Sale."* Miss it
and the distributor **forfeits the annual scheme entirely**, whatever slab they reached.

**But April + May + June is only 20.7% of a normal year.** At 30 June, **79% of the year has not
happened.** **March alone (12.3%) is bigger than April and May combined (12.4%).**

So **you cannot judge this today.** Present it as a **seasonally-adjusted projection**:
*"Projected to finish at 87% of last year — at risk"* — with the share of year elapsed shown alongside.
**Never present a part-year run-rate as a settled fact.**

Seasonality (share of annual sales): Apr 4.2, May 8.2, Jun 8.3, Jul 7.3, Aug 7.0, Sep 7.4, Oct 7.1,
Nov 8.5, Dec 10.1, Jan 10.1, Feb 9.6, **Mar 12.3**.

---

## TIMING — why this is urgent

**Q1 (Apr–Jun) is CLOSED.** That ₹2.49 Cr is gone.
**Q2 (Jul–Sep) has just started** — and because of the 25th-of-the-month rule, the real deadline is
**25 September**. There is maximum runway right now. Build for Q2.

---

## DATA SOURCES (all live — no uploads, no manual entry)

- **Slab base (sale)** — SALE SHEET 26-27 `19LQGpkbZiecGaXdBvl48rPZT2LUz3sKekeKX5fHu7Ps`
  (Taxable Value = col M, Customer = col E, GROUP = col N, State Head = col Q, Date = col C)
- **Order pattern (for bulk-order detection)** — Order Sheet 26-27 `1HFBAtvbAskejVkjuO8zHoEsE-pBAFij2ERMKFEvt64A`
- **Dues / collection** — PARTY O/S & PAYMENT 26-27 `1oHFpXqVDPRF3Vi3WV9MdNcxkHNjgytLPxXUQgM6o1ok`
- **Channel (to exclude Govt/Project)** — rate list Sheet2 `1njO-srsS29qiE4t45-zr5njbB7R2Zb-oSnv2NL1ONY4`
- **Slabs, basket map, conditions** — the attached `Prayag_Scheme_Master.xlsx`

---

## MISSING — tell the client, do not invent

**Master carton sizes per Cat No** (e.g. how many pieces in one carton of Teflon Tape). Without this,
carton-based single-bill schemes cannot be evaluated automatically. **Flag it in Data Health and ask
for it.** Do not guess.

---

## ACCEPTANCE

- [ ] Nudge List generates for Q2 (Jul–Sep) from live sale data, ranked by what the distributor earns.
- [ ] **ROI filter suppresses anything under 5%.**
- [ ] Distributors with **overdue bills show BLOCKED**, not a nudge.
- [ ] **Govt / GeM / JJM / Project excluded** from every slab base.
- [ ] Slab base uses **dispatched sale**, not order booking.
- [ ] Deadline shown as **25 September**, not 30 September.
- [ ] Annual clause shown as a **projection**, with % of year elapsed.
- [ ] Bulk Order Engine spots consolidation opportunities from the trailing order pattern.
- [ ] Sales Head Cockpit rolls the nudge list up by territory.
- [ ] Every figure is live. No uploads. No manual entry.
